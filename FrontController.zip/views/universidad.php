<main>
        <h1>Bienvenido a mi Universidad</h1>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Natus nisi mollitia eveniet consequuntur maiores? Autem quos, dolorum dolorem dolore adipisci, laudantium et id, mollitia quis nulla totam suscipit? Atque, expedita.</p>
        <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Aliquid exercitationem sunt ipsum quam assumenda alias eveniet voluptates pariatur, nostrum, sapiente sequi quia, aperiam ut maxime id at ad sit voluptas.</p>
    </main>