<main>
        <h1>Bienvenido a mi Universidad UGB </h1>
        <p>Bienvenidos a la felicidad!.</p>
        <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Aliquid exercitationem sunt ipsum quam assumenda alias eveniet voluptates pariatur, nostrum, sapiente sequi quia, aperiam ut maxime id at ad sit voluptas.</p>
    </main>