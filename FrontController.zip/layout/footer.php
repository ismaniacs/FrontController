<footer>
        <h3>Este es un footer</h3>
    </footer>
</body>
</html>