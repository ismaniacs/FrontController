<?php
require_once "render/BaseLayout.php";
BaseLayout::renderHead();
BaseLayout::renderUniversidad();
BaseLayout::renderFoot();