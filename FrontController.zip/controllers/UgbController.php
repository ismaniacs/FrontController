<?php

class Ugb
{
    public function showUgb()
    {
        require_once "models/Ugb.php";
        $ugb = new Ugb();
        $ugb = $ugb->showUgb();
        require_once "views/ugb.php";
    }
}