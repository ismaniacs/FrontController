<?php

class Ugb
{
    public function showUgb()
    {
        $UgbDir = "Ugb.php";
        
        return $UgbDir;
    }
}