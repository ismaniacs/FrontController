<?php

class Universidad
{
    public function showUniversidad()
    {
        $UniversidadDir = "universidad.php";
        
        return $UniversidadDir;
    }
}