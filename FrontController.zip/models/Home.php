<?php

class Home
{
    public function showHome()
    {
        $homeDir = "home.php";
        
        return $homeDir;
    }
}